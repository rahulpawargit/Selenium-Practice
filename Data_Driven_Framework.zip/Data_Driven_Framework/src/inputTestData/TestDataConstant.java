package inputTestData;

public class TestDataConstant {
	 
    public static final String URL = "https://10.10.87.103/UI/";

    public static final String Path_TestData = "C://Users//cupadhma//workspace//Selenium//ClassfifthMarch//Data_Driven_Framework//";

    public static final String File_TestData = "TestData.xlsx";

 }